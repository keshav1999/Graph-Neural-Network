"""Package for model zoo."""
from . import chem
