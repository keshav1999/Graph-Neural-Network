wget https://s3.us-east-2.amazonaws.com/dgl.ai/dataset/AGENDA.tar.gz
mkdir data
tar -C data/ -xvzf AGENDA.tar.gz
