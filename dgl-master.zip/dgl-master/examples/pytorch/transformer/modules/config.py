# Define some global constants/variables
VIZ_IDX = 3
