.. _apirandom:

DGL Random Number Generator Controls
====================================

.. automodule:: dgl.random

.. autosummary::
    :toctree: ../../generated

    seed
