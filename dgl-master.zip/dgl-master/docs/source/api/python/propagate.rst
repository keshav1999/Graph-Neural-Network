Message Propagation
===================

.. automodule:: dgl.propagate

.. autosummary::
    :toctree: ../../generated/

    prop_nodes
    prop_edges
    prop_nodes_bfs
    prop_nodes_topo
    prop_edges_dfs
