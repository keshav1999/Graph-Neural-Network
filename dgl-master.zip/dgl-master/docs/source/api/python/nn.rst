.. _apinn:

NN Modules
==========

.. automodule:: dgl.nn

.. toctree::

   nn.pytorch
   nn.mxnet
   nn.tensorflow
