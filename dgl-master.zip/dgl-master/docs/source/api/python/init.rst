.. _apiinit:

Feature Initializer
===================

.. automodule:: dgl.init
.. autosummary::
   :toctree: ../../generated/

   base_initializer
   zero_initializer
