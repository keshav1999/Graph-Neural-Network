# install libraries for python package on ubuntu
#pip2 install nose numpy cython scipy networkx matplotlib nltk requests[security] tqdm
pip3 install nose numpy cython scipy networkx matplotlib nltk requests[security] tqdm
